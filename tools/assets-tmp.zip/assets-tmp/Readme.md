# Simple Markown GUI 

## Init environment

```
>python -m pip install --upgrade pip setuptools virtualenv
>mkdir PROJ && cd PROJ
>python -m venv env
>env\Scripts\activate.bat
(env) PROJ>pip install pyside6
>python
Python 3.13.12 (tags/v3.13.12:1cbe481, Feb  3 2026, 18:22:25) [MSC v.1944 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> import PySide6
>>> PySide6.__version__
'6.11.0'
>>> exit();
(env) PROJ>
```


```
# Fix extra newlines in code blocks
markdown_text = re.sub(r'```(.*?)```', lambda m: '```' + m.group(1).replace('\n\n', '\n') + '```', markdown_text, flags=re.DOTALL)
```

Диалог чтения файла:

```python
from PySide6.QtWidgets import QFileDialog

def open_md(editor_widget):
    """Open a markdown file and set it as markdown for display."""
    file_path, _ = QFileDialog.getOpenFileName(editor_widget, "Open Markdown", "", "Markdown Files (*.md);;All Files (*)")
    if not file_path:
        return

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            markdown_text = file.read()
    except OSError:
        return

    editor_widget.setMarkdown(markdown_text)
```